<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly


/**
 * Class Sensei_Domain_Models_Exception
 * @package Domain_Models
 * @since 1.9.13
 */
class Sensei_Domain_Models_Exception extends Exception {
}